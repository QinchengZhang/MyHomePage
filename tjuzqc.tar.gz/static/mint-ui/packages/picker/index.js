export { default } from './src/picker.vue';
