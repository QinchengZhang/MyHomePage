import 'mint-ui/src/style/empty.css';
export { default } from './src/lazyload.js';
